var name = prompt("¿Cuál es tu nombre?"); ;
var apellido = prompt ("¿Cuál es tu apellido?");
var nacimiento = prompt("¿En qué año naciste?");
var actual = 2022;
var edad = actual - nacimiento;

if(edad >= 18){
    alert("Eres mayor de edad");
}else 
    alert("Eres menor de edad");
}  