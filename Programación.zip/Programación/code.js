var x=1;
var y=7;
var z=x+y;
alert("El valor de z es " + z );
